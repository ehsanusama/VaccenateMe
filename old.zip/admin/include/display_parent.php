<?php


function displayparent(){
    $user=$_SESSION['id'];
    $status=$_SESSION['status'];

    include ("connection/conection.php");

    //admin display
    if($status==1){
        include ("connection/conection.php");

        $sql ="SELECT * FROM user ORDER BY u_id DESC ";
        $qrun = mysqli_query($conn, $sql);
        if(mysqli_num_rows($qrun) >0 ){

            while ($data = mysqli_fetch_array($qrun)){
                ?>

                <tr>
                    <td>
                        <h2 class="table-avatar">
                            <a href="#"><?php  echo $data['u_fname'] ;?>  <?php  echo $data['u_lname'] ;?></a>
                        </h2>
                    </td>
                    <td>
                        <h2 class="table-avatar">
                            <a href="#"><p style="text"> <?php  echo $data['u_cnic'] ;?> </a>
                        </h2>
                    </td>
                    <td>
                        <h2 class="table-avatar">
                            <a href="#"><p style="text"> <?php  echo $data['u_phone'] ;?> </a>
                        </h2>
                    </td>
                     <td>
                        <h2 class="table-avatar">
                            <a href="#"><p style="text"> <?php  echo $data['u_email'] ;?> </a>
                        </h2>
                    </td>
                    <td class="table-avatar">
                        <div class="actions">
                            <a class="btn btn-sm bg-danger-light" data-toggle="modal" href="?delete=<?php echo $data['u_id']; ?>">
                                <i class="fe fe-trash"></i> Delete
                            </a>
                        </div>
                    </td>
                </tr>

                <?php


            }
        }

    }


}
?>
