<?php

include ("connection/conection.php");

?>

<?php


  function displayappintment(){
      $user=$_SESSION['id'];
      $status=$_SESSION['status'];

      include ("connection/conection.php");

   $sql ="SELECT * FROM baby  Where p_id=$user ORDER BY b_id DESC ";
      include ("connection/conection.php");
   $qrun = mysqli_query($conn, $sql);

   if(mysqli_num_rows($qrun) >0 ){

      while ($data = mysqli_fetch_array($qrun)){
          ?>

          <tr>
              <td>
                  <h2 class="table-avatar">
                      <a href="#"><?php  echo $data['b_fname'] ;?>  <?php  echo $data['b_lname'] ;?></a>
                  </h2>
              </td>
              <td>
                  <h2 class="table-avatar">
                      <a href="#"><p style="text"> <?php  echo $data['bfather_name'] ;?> </a>
                  </h2>
              </td>
              <td>
                  <h2 class="table-avatar">
                      <a href="#"><p style="text"> <?php  echo $data['b_gender'] ;?> </a>
                  </h2>
              </td>

              <td><?php  echo $data['b_dob'] ;?> <span class="text-primary d-block"><?php  echo $data['b_tob'] ;?></span></td>


              <td>
                  <h2 class="table-avatar">
                      <a href="#"><p style="text"> <?php  echo $data['b_city'] ;?> </a>
                  </h2>
              </td>

              <td class="text-right">
                  <div class="actions">
                      <a class="btn btn-sm bg-primary-light" data-toggle="modal" href="?edit=<?php echo $data['b_id']; ?>">
                          <i class="fe fe-edit"></i> Edit
                      </a>
                      <a class="btn btn-sm bg-danger-light" data-toggle="modal" href="?delete=<?php echo $data['b_id']; ?>">
                          <i class="fe fe-trash"></i> Delete
                      </a>
                  </div>
              </td>
          </tr>

          <?php


      }
   }

      //admin display
              if($status==1){
                  include ("connection/conection.php");

                  $sql ="SELECT * FROM baby ORDER BY b_id DESC ";
                  $qrun = mysqli_query($conn, $sql);
                  if(mysqli_num_rows($qrun) >0 ){

                      while ($data = mysqli_fetch_array($qrun)){
                          ?>

                          <tr>
                              <td>
                                  <h2 class="table-avatar">
                                      <a href="#"><?php  echo $data['b_fname'] ;?>  <?php  echo $data['b_lname'] ;?></a>
                                  </h2>
                              </td>
                              <td>
                                  <h2 class="table-avatar">
                                      <a href="#"><p style="text"> <?php  echo $data['bfather_name'] ;?> </a>
                                  </h2>
                              </td>
                              <td>
                                  <h2 class="table-avatar">
                                      <a href="#"><p style="text"> <?php  echo $data['b_gender'] ;?> </a>
                                  </h2>
                              </td>

                              <td><?php  echo $data['b_dob'] ;?> <span class="text-primary d-block"><?php  echo $data['b_tob'] ;?></span></td>
                              <td>
                                  <h2 class="table-avatar">
                                      <a href="#"><p style="text"> <?php  echo $data['b_city'] ;?> </a>
                                  </h2>
                              </td>


                              <td class="text-right">
                                  <div class="actions">
                                      <a class="btn btn-sm bg-primary-light" data-toggle="modal" href="?edit=<?php echo $data['b_id']; ?>">
                                          <i class="fe fe-edit"></i> Edit
                                      </a>
                                      <a class="btn btn-sm bg-danger-light" data-toggle="modal" href="?delete=<?php echo $data['b_id']; ?>">
                                          <i class="fe fe-trash"></i> Delete
                                      </a>
                                  </div>
                              </td>
                          </tr>

                          <?php


                      }
                  }

                    }


  }
?>