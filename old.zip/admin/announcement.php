<?php  include ("login/register_user.php");

if(isset($_SESSION['id']  )){

    ?>

    <?php  include "include/announcement.php";?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Announcement</title>

        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- Feathericon CSS -->
        <link rel="stylesheet" href="assets/css/feathericon.min.css">

        <!-- Select2 CSS -->
        <link rel="stylesheet" href="assets/css/select2.min.css">

        <!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="assets/js/swl.js"></script>
        <!--[if lt IE 9]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

    <!-- Main Wrapper -->
    <div class="main-wrapper">

        <!-- Header -->
        <?php  include ("include/section/header.php"); ?>
        <!-- /Header -->
        <!-- Sidebar -->
        <?php  include ("include/section/sidebar.php"); ?>
        <!-- /Sidebar -->

        <!-- Page Wrapper -->
        <div class="page-wrapper">

            <div class="content container-fluid">

                <!-- Page Header -->
                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title">Announcement Form</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#l">Dashboard</a></li>
                                <li class="breadcrumb-item active">Add Announcement</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->



                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Send Notification </h4>
                            </div>
                            <div class="card-body">
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Vacc Name</label>
                                                <input type="text" class="form-control" name="v_name">
                                            </div>
                                            <div class="form-group">
                                                <label>Vaccination Time Period</label>
                                                <select class="select" name="v_time">
                                                    <option>Select</option>
                                                    <option value="1-2 Week">1-2 Week</option>
                                                    <option value="2-3 Week">2-3 Week</option>
                                                    <option value="3-4 Week">3-4 Week</option>

                                                </select>
                                            </div>

                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Age</label>
                                                <select class="select" name="v_age">
                                                    <option>Select</option>
                                                    <option value="0-3 Months">0-3 Months</option>
                                                    <option value="3-6 Months">3-6 Months</option>
                                                    <option value="6-9 Months">6-9 Months</option>
                                                    <option value="9-12 Months">9-12 Months</option>
                                                    <option value="1+ Year">1+ Year</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Vaccination Category</label>
                                                <select class="select" name="v_cat">
                                                    <option>Select</option>
                                                    <option value="Polio(IPV)">Polio(IPV)</option>
                                                    <option value="Chickenpox">Chickenpox</option>
                                                </select>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Vaccination Description</label>
                                                <textarea name="v_dec" id="" cols="" rows="5" type="text" class="form-control" ></textarea>

                                            </div>

                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <button type="submit" class="btn btn-primary" name="annc_send">Submit</button>
                                    </div>
                                </form>
                                <?php  create_vaccine(); ?>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
        <!-- /Page Wrapper -->

    </div>


    <?php //if "email" variable is filled out, send email

    if (isset($_REQUEST['annc_send']))
    {      //Email information
        include ("connection/conection.php");

        $sql ="SELECT * FROM user ";

        $qrun = mysqli_query($conn, $sql);
        if(mysqli_num_rows($qrun) >0 ){
            while ($data = mysqli_fetch_array($qrun)){

                $to = $data['u_email'].",";
                $from ='usamaehsan2328@gmail.com';
                $fromName = 'Usama';
                $mainmessage = 'Alert Msg';
                $subject = "Email from Vaccinatemeg website This is sample msg";

                $htmlContent = ' 
    <html> 
    <head> 
        <title>Apexbilling</title> 
    </head> 
    <body> 
        <h1>Someone Contact us!</h1> 
        <table cellspacing="0" style="border: 1px solid #20d34a; width: 100%;"> 
            <tr> 
                <th>Name:</th><td>Apex Billing</td> 
            </tr> 
            <tr style="background-color: #c2c2c2;"> 
                <th>Email:</th><td>'. $from .'</td> 
            </tr> 
            <tr> 
                <th>Contact Message</th>
                <td>
                 '.$mainmessage.'
                
                </td> 
            </tr> 
        </table> 
    </body> 
    </html>';
// Set content-type header for sending HTML email
                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// Additional headers
                $headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n";
                /*
                $headers .= 'Cc: welcome@example.com' . "\r\n";
                $headers .= 'Bcc: welcome2@example.com' . "\r\n";
                 */
// Send email
                if(mail($to, $subject, $htmlContent, $headers)){
                    echo 'Email has sent successfully.';
                }else{
                    echo 'Email sending failed.';
                }

            }


            }


        }


       


    ?>
    <!-- /Main Wrapper -->

    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>

    <!-- Bootstrap Core JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Slimscroll JS -->
    <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Select2 JS -->
    <script src="assets/js/select2.min.js"></script>

    <!-- Custom JS -->
    <script  src="assets/js/script.js"></script>
    </body>

    <!-- Mirrored from dreamguys.co.in/demo/doccure/admin/form-vertical.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:55 GMT -->
    </html>

<?php }
else{
    echo "please login first";
}



?>