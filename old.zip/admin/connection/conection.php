<?php

$conn = mysqli_connect("localhost","u340575409_vaccinateme","Faheem950","u340575409_vms");



?>